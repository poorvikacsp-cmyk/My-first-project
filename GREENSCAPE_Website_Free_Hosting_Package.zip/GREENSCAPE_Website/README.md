# GREENSCAPE — Smart Urban Greening Planner

A mobile-friendly static website for the GREENSCAPE student project.

## Features
- Live current weather lookup for a city using Open-Meteo geocoding + forecast APIs (no API key required).
- Manual soil type, pH, moisture and sunlight inputs.
- Indicative planting-category recommendations based on selected site and conditions.
- Filterable urban greening ideas library.
- QR-code generation after the site has a public HTTPS URL.

## Preview locally
Open `index.html` in a modern browser. Live weather requires an internet connection.

## Free publishing with GitHub Pages
1. Sign in or create a free GitHub account.
2. Create a new **public** repository, for example `greenscape-planner`.
3. Upload `index.html` to the repository root.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`, then Save.
7. Wait for GitHub Pages to publish. The public address will look like:
   `https://YOUR-USERNAME.github.io/greenscape-planner/`
8. Open that public HTTPS address on your phone or laptop. Press **Create QR for this page** at the bottom of the website. The generated QR will point to the published page.

Alternative: Netlify Drop can publish a folder by dragging it into the Netlify Drop page, subject to its current free-tier terms.

## Important project notes
- Soil pH and moisture are manual inputs. The website does not have a soil sensor connection.
- Weather is live from Open-Meteo when the page is online and the browser can reach the service.
- Plant suggestions are broad categories, not an authoritative species list. Confirm species, mature size, root behaviour, water needs, invasiveness and site permissions with local horticulture / municipal guidance.
- The website is a planning prototype. Do not claim measured temperature reduction, air-quality improvement or plant survival unless your team has collected supporting data.

## Attribution
Weather data: Open-Meteo (https://open-meteo.com/). Check the provider's current terms and attribution requirements before public or commercial use.
QR image generation: QRServer API is called only when the published page's QR button is used.
